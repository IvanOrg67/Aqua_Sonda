import 'package:flutter/material.dart';
import 'theme/app_colors.dart';
import 'widgets/neumorphic.dart';
import 'services/api_installaciones_service.dart';

class PantallaInstalaciones extends StatelessWidget {
  const PantallaInstalaciones({super.key});

  static const String _cardBg =
      'assets/images/image-aNvpXQcowFLBnfeDs2JfYaMI2hEiM5.png'; // fondo de cada tarjeta

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final shortest = size.shortestSide;
    final isTablet = shortest >= 600;
    final gridCount = isTablet ? 2 : 1;
    final cardHeight = isTablet ? 220.0 : 200.0;

    // 👉 usamos instancia del servicio (no métodos estáticos)
    final api = ApiInstalacionesService();

    return Scaffold(
      appBar: AppBar(title: const Text('Instalaciones')),
      body: FutureBuilder<List<Instalacion>>(
        future: api.listar(),
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Text('Error: ${snap.error}',
                    style: const TextStyle(color: AppColors.error)),
              ),
            );
          }
          final items = snap.data ?? [];
          if (items.isEmpty) {
            return const Center(child: Text('Sin instalaciones registradas'));
          }

          return GridView.builder(
            padding: const EdgeInsets.all(16),
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: gridCount,
              childAspectRatio: (16 / 9), // tarjetas panorámicas
              mainAxisSpacing: 14,
              crossAxisSpacing: 14,
            ),
            itemCount: items.length,
            itemBuilder: (context, i) {
              final it = items[i];
              return _InstalacionCard(
                instalacion: it,
                height: cardHeight,
                backgroundAsset: _cardBg,
                onTap: () {
                  // 👉 tu modelo no tiene toJson(); armamos un Map con campos reales
                  Navigator.pushNamed(
                    context,
                    '/instalacion',
                    arguments: {
                      'id_instalacion': it.id,
                      'nombre_instalacion': it.nombre,
                      'estado_operativo': it.estado,
                      'id_empresa': it.idEmpresa,
                      'descripcion': it.descripcion,
                      'fecha_instalacion': it.fechaInstalacion,
                      'tipo_uso': it.uso,
                    },
                  );
                },
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          // TODO: crear instalación (formulario propio)
          // Si quieres crear aquí, usa:
          // await api.crear(
          //   idEmpresaSucursal: 1, // IDs reales de /api/seed/min
          //   idProceso: 1,
          //   nombreInstalacion: 'Estanque X',
          //   fechaInstalacion: '2025-09-07',
          //   estadoOperativo: 'activo',
          //   tipoUso: 'acuicultura',
          //   descripcion: 'Demo',
          // );
          // y luego setState/refresh (si cambias a Stateful).
        },
        icon: const Icon(Icons.add),
        label: const Text('Nueva instalación'),
      ),
    );
  }
}

class _InstalacionCard extends StatelessWidget {
  final Instalacion instalacion;
  final double height;
  final String backgroundAsset;
  final VoidCallback onTap;

  const _InstalacionCard({
    required this.instalacion,
    required this.height,
    required this.backgroundAsset,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.18),
              blurRadius: 12,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: Stack(
            fit: StackFit.expand,
            children: [
              // Fondo imagen piscina
              Image.asset(
                backgroundAsset,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(color: Colors.blueGrey),
              ),
              // Degradado para legibilidad
              Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.transparent, Colors.black54],
                  ),
                ),
              ),
              // Contenido
              Padding(
                padding: const EdgeInsets.all(14),
                child: Stack(
                  children: [
                    // Estado arriba-derecha
                    Positioned(
                      right: 0,
                      top: 0,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          color: ((instalacion.estado.isEmpty ? '—' : instalacion.estado) == 'activo'
                              ? Colors.green.withOpacity(.22)
                              : Colors.orange.withOpacity(.22)),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          instalacion.estado.isEmpty ? '—' : instalacion.estado,
                          style: TextStyle(
                            color: instalacion.estado == 'activo'
                                ? Colors.greenAccent
                                : Colors.orangeAccent,
                            fontWeight: FontWeight.w700,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ),
                    // Nombre + info abajo
                    Positioned(
                      left: 0,
                      right: 0,
                      bottom: 0,
                      child: Row(
                        children: [
                          Container(
                            width: 46,
                            height: 46,
                            decoration: Neu.concave(radius: 12),
                            child: const Icon(Icons.pool_rounded, color: Colors.white, size: 24),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  instalacion.nombre,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w800,
                                    fontSize: 16,
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  instalacion.descripcion.isNotEmpty ? instalacion.descripcion : '—',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    color: Colors.white70,
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 8),
                          const Text(
                            '0 sensores',
                            style: TextStyle(
                              color: Colors.white70,
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
