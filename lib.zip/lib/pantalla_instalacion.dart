// lib/pantalla_instalacion.dart
import 'package:flutter/material.dart';
import 'theme/app_colors.dart';

/// Pantalla de DETALLE de una instalación.
/// Lee los argumentos enviados con Navigator.pushNamed('/instalacion', arguments: {...})
/// y los muestra. Esto evita el choque con PantallaInstalaciones.
class PantallaInstalacion extends StatelessWidget {
  PantallaInstalacion({super.key});

  @override
  Widget build(BuildContext context) {
    final args =
        ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;

    final nombre = (args?['nombre_instalacion'] as String?) ?? 'Instalación';
    final estado = (args?['estado_operativo'] as String?) ?? '—';
    final fecha = (args?['fecha_instalacion'] as String?) ?? '—';
    final tipoUso = (args?['tipo_uso'] as String?) ?? '—';
    final descripcion = (args?['descripcion'] as String?) ?? '—';
    final idInstalacion = (args?['id_instalacion'] as int?)?.toString() ?? '—';
    final idEmpresa = (args?['id_empresa_sucursal'] as int?)?.toString() ?? '—';
    final idProceso = (args?['id_proceso'] as int?)?.toString() ?? '—';

    return Scaffold(
      appBar: AppBar(title: Text(nombre)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _Item(label: 'Estado', value: estado),
          _Item(label: 'Fecha instalación', value: fecha),
          _Item(label: 'Tipo de uso', value: tipoUso),
          _Item(label: 'Descripción', value: descripcion),
          const Divider(height: 24),
          _Item(label: 'ID instalación', value: idInstalacion),
          _Item(label: 'ID empresa/sucursal', value: idEmpresa),
          _Item(label: 'ID proceso', value: idProceso),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: () {
              // Aquí podrás abrir lecturas/sensores, etc.
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Acción futura')),
              );
            },
            icon: const Icon(Icons.sensors),
            label: const Text('Ver sensores (próximamente)'),
          ),
        ],
      ),
    );
  }
}

class _Item extends StatelessWidget {
  final String label;
  final String value;
  const _Item({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 150,
            child: Text(label,
                style: const TextStyle(
                    fontWeight: FontWeight.w600, color: AppColors.textSecondary)),
          ),
          const SizedBox(width: 8),
          Expanded(child: Text(value)),
        ],
      ),
    );
  }
}
