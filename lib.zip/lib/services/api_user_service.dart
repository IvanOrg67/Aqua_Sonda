import 'api_client.dart';

class UsuarioDto {
  final int idUsuario;
  final String nombre;
  final String correo;
  final int idRol;
  final String? token;

  UsuarioDto({
    required this.idUsuario,
    required this.nombre,
    required this.correo,
    required this.idRol,
    this.token,
  });

  factory UsuarioDto.fromLogin(Map<String, dynamic> json) {
    final u = (json['usuario'] as Map<String, dynamic>);
    return UsuarioDto(
      idUsuario: (u['id_usuario'] as num).toInt(),
      nombre: (u['nombre'] ?? u['nombre_completo'] ?? '') as String,
      correo: (u['correo'] as String?) ?? '',
      idRol: (u['id_rol'] as num).toInt(),
      token: json['token'] as String?,
    );
  }
}

class ApiUserService {
  final _api = ApiClient.instance;

  Future<UsuarioDto> register({
  required String nombre,
  required String correo,
  required String password,
  required int idRol,
  String? telefono,
  }) async {
    final res = await _api.post('/auth/register', body: {
      'nombre': nombre,
      'correo': correo,
      'password': password,
      'id_rol': idRol,
      if (telefono != null && telefono.isNotEmpty) 'telefono': telefono,
    });
    final data = _api.decodeOrThrow(res) as Map<String, dynamic>;
    final user = UsuarioDto.fromLogin(data);
    final token = data['token'] as String?;
    if (token != null && token.isNotEmpty) await _api.saveToken(token);
    return user;
  }

  Future<UsuarioDto> login({
    required String correo,
    required String password,
  }) async {
    final res = await _api.post('/auth/login', body: {
      'correo': correo,
      'password': password,
    });
    final data = _api.decodeOrThrow(res) as Map<String, dynamic>;
    final user = UsuarioDto.fromLogin(data);
    final token = data['token'] as String?;
    if (token != null && token.isNotEmpty) await _api.saveToken(token);
    return user;
  }

  Future<void> logout() => _api.clearToken();
  Future<String?> currentToken() => _api.getToken();
}
